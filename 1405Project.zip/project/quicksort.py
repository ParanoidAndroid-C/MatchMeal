def quick_sort(myList, low, high, index,rev):
    if low < high:
        p = partition(myList, low, high, index, rev)
        quick_sort(myList, low, p, index, rev)
        quick_sort(myList, p+1, high, index, rev)
           
    return myList   

def partition(myList, low, high, index, rev):
    pivot = myList[low][index]
    i = low - 1
    j = high + 1
    
    while True:
        i += 1
        j -= 1
        
        while myList[i][index] * rev < pivot * rev:
            i += 1
            
        while myList[j][index] * rev > pivot * rev:
            j -= 1
            
        if i >= j:
            return j
            
        myList[i], myList[j] = myList[j], myList[i]
        
#answ = [[4, 5, 8], [4, 5, 4], [4, 5, 10],[4, 5, 5],[4, 5, 2],[4, 5, 3]]
#print(quick_sort(answ, 0, len(answ)-1, 2, -1))