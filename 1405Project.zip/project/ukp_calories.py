def ukp(w, weights, values, myData, index):
    MAX_PRICE = 1000
    final_values = [MAX_PRICE]*(w+1)
    final_values[0] = 0
    rame = [[] for i in range(0, w+1)]
    past_max = 0
    past_max_index = 0
    
    for i in range(0, len(weights)):
        if weights[i] <= w:
            final_values[weights[i]] = values[i]
            rame[weights[i]].append(0)
            rame[weights[i]].append(i)
        
    for i in range(0, w+1):
        for j in range(0, len(weights)):
            if weights[j] <= i:     
                if final_values[i-weights[j]] + values[j] < final_values[i]:
                    rame[i].clear()
                    rame[i].append(i-weights[j])
                    rame[i].append(j)
                final_values[i] = min(final_values[i], final_values[i-weights[j]] + values[j])
                if final_values[i] != MAX_PRICE:
                    past_max = final_values[i]
                    past_max_index = i
                    
             

    if final_values[w] == MAX_PRICE:
        return (past_max, items(rame, values, past_max_index, index))
    else:
        return (final_values[w], items(rame, values, w, index))
    
def items(myList, values, max_w, index):
    used_items = []
    summ = 0
    k = max_w
    while k != 0:
        summ += values[myList[k][1]]
        used_items.append(index[myList[k][1]])
        k = myList[k][0]

    return(used_items)
        

        