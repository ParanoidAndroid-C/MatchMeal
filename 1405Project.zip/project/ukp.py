def ukp(w, weights, values, myData, item_indexes):
    final_values = [0]*(w+1)
    weight_indexes = [[] for i in range(0, w+1)]
    ram = []
    
    for i in range(0, w+1):
        for j in range(0, len(weights)):
            if weights[j] <= i:
                if final_values[i-weights[j]] + values[j] > final_values[i]:
                    weight_indexes[i].clear()
                    weight_indexes[i].append(i-weights[j])
                    weight_indexes[i].append(j)
                final_values[i] = max(final_values[i], final_values[i-weights[j]] + values[j])
    ram = items(weight_indexes, values, final_values[w], w, item_indexes)
    return (final_values[w], ram)
    
def items(myList, values, max_val, max_w, item_indexes):
    used_items = []
    summ = 0
    k = max_w
    while summ < max_val:
        summ += values[myList[k][1]]
        used_items.append(item_indexes[myList[k][1]])
        k = myList[k][0]
    return(used_items)
        