import importlib
import tkinter as tk
import time
import operator

RES_NAME_LABEL_X = 150
RES_NAME_LABEL_Y = 30
CURRENT_X = 450
CURRENT_Y = 250

#Generate Data
modname_generate = "generatedata"
module_generate = importlib.import_module(modname_generate)

#Read data
modname_read = "readdata"
funcname = "readData"
module_read = importlib.import_module(modname_read)
func = getattr(module_read, funcname)
myData = func('data.txt')


empty = {}

cnt_window2 = 0
cnt_window3 = 0

def allergies(s):
    for k in myData:
        for t in range(0, len(myData[k]['restaurant_menu'])):
            key_string = str(k) + str(t)
            if key_string not in empty:
                if s in myData[k]['restaurant_menu'][t]['item_ingredients']:
                    del(myData[k]['restaurant_menu'][t]) 
                    empty[key_string] = True       

#add more allergies
def add_more():
    listbox.delete(0, 'end')
    listbox.place_forget()
    
    if ingredient_name.get() != 'see the list':
        ingredients_list.remove(ingredient_name.get())
        allergies(ingredient_name.get())        
        
    if allergies_string.get() != '':
        if allergies_string.get().lower() in ingredients_list:
            ingredients_list.remove(allergies_string.get())
            allergies(allergies_string.get().lower())
        else:
            message = tk.Message(window, text="Sorry there are no such ingredient : (")
            message.place( x= 540, y = 380)
            message.after(3500, message.destroy)
            

    menu = tk.OptionMenu(window, ingredient_name, *ingredients_list)
    menu.place(x = 510, y = 145)
    ingredient_name.set('see the list')
    allergies_string.delete(0, 'end')    


# GUI
window = tk.Tk()
window.title("MatchMeal")
window.geometry("900x500")


l = tk.Label(window, text = "Hi there! What's your mood today?") 
l.place(x=80, y=20)
 

v = tk.IntVar()
 
tk.Radiobutton(window, 
              text="Hangry, let me give you my budget",
              variable=v, 
              value=1).place(x = 100, y = 50)
tk.Radiobutton(window, 
              text="On a diet, let me choose a maximum amount of calories", 
              variable=v, 
              value=2).place(x = 100, y = 90)
              
calories_string = tk.Entry(window)
calories_string.place(x = 450, y = 94)

money_string = tk.Entry(window)
money_string.place(x = 450, y = 54)



# allergies
allergies_label = tk.Label(window, text = "Would you like to add allergies?") 
allergies_label.place(x = 80, y = 120) 
allergies_text_label = tk.Label(window, text = "Enter ingredient name or choose it from the list:")
allergies_text_label.place( x = 100, y= 150)
 
ingredient_name = tk.StringVar(window)
ingredient_name.set('see the list') # default value
ingredients_list  = ['beef', 'ham', 'turkey', 'chicken', 'pork', 'bacon', 'lamb', 'tomato', 'lettuce','cucumber', 'broccoli', 'cheese', 'yogurt', 'milk', 'butter']

menu = tk.OptionMenu(window, ingredient_name, *ingredients_list)
menu.place(x = 510, y = 145)

def make_suggestions(event):
    if cnt_window2 > 0:
        window2.destroy()
    listbox.delete(0, 'end')
    listbox.place_forget()
    if allergies_string.get() != '':
        for i in range(len(ingredients_list)):
            if ingredients_list[i].startswith(allergies_string.get().lower()):
                listbox.insert('end', ingredients_list[i])
                listbox.place(x=370, y=170+listbox.size())   
        
   

allergies_string = tk.Entry(window)
allergies_string.place(x = 370, y = 150)
window.bind("<KeyPress>", make_suggestions)

def ingredient_onselect(event):
    w = event.widget
    if len(w.curselection()) > 0:
        value = w.get(int(w.curselection()[0]))
        allergies_string.delete(0, 'end')
        allergies_string.insert(0, value)
        listbox.delete(0, 'end')
        listbox.place_forget()
    
    
listbox = tk.Listbox(window)
listbox.bind('<<ListboxSelect>>', ingredient_onselect)

button_add = tk.Button(window, text = 'Add', width = 10, command =  add_more)
button_add.place(x = 620, y = 147)

# sort
sort_label = tk.Label(window, text = "How would you like to sort the results?") 
sort_label.place(x=80, y=210)
 
v2 = tk.IntVar()
 
tk.Radiobutton(window, 
              text="By distance",
              variable=v2, 
              value=1).place(x = 100, y = 230)
tk.Radiobutton(window, 
              text="By meal calories (Only for hangry mood)", 
              variable=v2, 
              value=2).place(x = 100, y = 270)         
tk.Radiobutton(window, 
              text="By restaurant raitings", 
              variable=v2, 
              value=3).place(x = 100, y = 310)  
tk.Radiobutton(window, 
              text="By cost (Only for diet mood)", 
              variable=v2, 
              value=4).place(x = 100, y = 350)              


def display_map():
    global cnt_window3
    global window3

    if cnt_window3 > 0:
        window3.destroy()
        cnt_window3 = 0
        
    window3 = tk.Toplevel(window)
    window3.title("Map")
    window3.geometry("900x500")
    cnt_window3 += 1
    
    C = tk.Canvas(window3, bg='green', height=500, width=900)
    C.create_oval(CURRENT_X, CURRENT_Y, CURRENT_X+10, CURRENT_Y+10, fill = 'blue')
   
    for i in range(len(answ)):
        if answ[i][0] != restaurant_num:
            C.create_oval(myData[answ[i][0]]['restaurant_location'][0],myData[answ[i][0]]['restaurant_location'][1] , myData[answ[i][0]]['restaurant_location'][0] + 10, myData[answ[i][0]]['restaurant_location'][1] + 10, fill = 'red')
        else:
            C.create_oval(myData[answ[i][0]]['restaurant_location'][0],myData[answ[i][0]]['restaurant_location'][1] , myData[answ[i][0]]['restaurant_location'][0] + 10, myData[answ[i][0]]['restaurant_location'][1] + 10, fill = 'yellow')
            

    C.pack()
    
def onselect(event):
    global answ
    global restaurant_num
    
    widget = event.widget
    restaurant_index = widget.curselection()[0]
    restaurant_name = widget.get(restaurant_index)
    restaurant_num = int(restaurant_name[10:len(restaurant_name)]) - 1
    
    ingredients_string = ''
    res_name_label.configure(text = 'Restaurant Name: ' + str(myData[restaurant_num]['restaurant_name']))
    
    if mood == 1:
        max_calories_label.configure(text = 'Maximum calories you can get: ' + str(answ[restaurant_index][1]))
    else:
        max_calories_label.configure(text = 'Minimum amount of money you will spend: ' + str(answ[restaurant_index][1]))
    for i in answ[restaurant_index][2]:
        ingredients_string = ingredients_string + myData[restaurant_num]['restaurant_menu'][i]['item_name'] + '- '+ 'ingredients: '+ str(myData[restaurant_num]['restaurant_menu'][i]['item_ingredients']) + '\n'
    
    ingredients_label.configure(text = ingredients_string)
    res_rating_label.configure(text = 'Restaurant rating: ' + str(myData[restaurant_num]['restaurant_rating']) + '/5')
    distance_label.configure(text = 'Distance to the restaurant: ' + str(myData[restaurant_num]['restaurant_location'][2]))
    items_label.configure(text = 'You should get the following items:')
    
    
    map_button = tk.Button(window2, text = 'Display map', command=display_map)
    map_button.place(x = 700, y = 340)

        
    
def calculate_distance(): 
    for i in myData:
        distance = ((myData[i]['restaurant_location'][0] - CURRENT_X) ** 2 + (myData[i]['restaurant_location'][1] - CURRENT_Y)**2) ** (1/2)
        myData[i]['restaurant_location'][2] = int(distance)

def new_activity():
    global window2
    global answ
    global res_name_label
    global max_calories_label
    global items_label
    global ingredients_label
    global res_rating_label
    global distance_label
    global cnt_window2
    global mood
    
    # check if window2 is already open. if yes then destroy it before opening a new one.
    if cnt_window2 > 0:
        window2.destroy()
        cnt_window2 = 0
    
    mood = v.get()
    answ = []
    
    if mood == 1:
        # Hungry
        if money_string.get().isnumeric():
            for i in myData:
                cost = []
                calories = []
                item_indexes = []
                for j in range(0, len(myData[i]['restaurant_menu'])):
                    key_string = str(i) + str(j)
                    if key_string not in empty:
                        cost.append(int(myData[i]['restaurant_menu'][j]['item_price']))
                        calories.append(int(myData[i]['restaurant_menu'][j]['item_calories']))
                        item_indexes.append(j)
                 
                modname_ukp = "ukp"
                funcname_ukp = "ukp"
                module_ukp = importlib.import_module(modname_ukp)
                func = getattr(module_ukp, funcname_ukp)
                max_calories, used_items = func(int(money_string.get()), cost, calories, myData, item_indexes)
                if max_calories != 0:
                    answ.append([i, max_calories, used_items, myData[i]['restaurant_location'][2], myData[i]['restaurant_rating']])
    elif mood == 2:
        #Diet
        if calories_string.get().isnumeric():
            for i in myData:
                cost = []
                calories = []
                item_indexes = []
                for j in range(0, len(myData[i]['restaurant_menu'])):
                    key_string = str(i) + str(j)
                    if key_string not in empty:
                        cost.append(int(myData[i]['restaurant_menu'][j]['item_price']))
                        calories.append(int(myData[i]['restaurant_menu'][j]['item_calories']))    
                        item_indexes.append(j)
                    
                modname_ukpc = "ukp_calories"
                funcname_ukpc = "ukp"
                module_ukpc = importlib.import_module(modname_ukpc)
                func = getattr(module_ukpc, funcname_ukpc)
                min_price, used_items = func(int(calories_string.get()), calories, cost, myData, item_indexes)
                if min_price != 0:
                     answ.append([i, min_price, used_items, myData[i]['restaurant_location'][2], myData[i]['restaurant_rating']])
    
    #sort   
    ind = 0
    rev = 1
    modname_sort = "quicksort"
    funcname = "quick_sort"
    module_sort = importlib.import_module(modname_sort)
    func = getattr(module_sort, funcname)
    
    sortby = v2.get()
    if ( mood == 1 and sortby == 4) or (mood == 2 and sortby == 2):
        message = tk.Message(window, text="Please select matching sort option :')")
        message.place( x= 540, y = 380)
        message.after(3500, message.destroy)
    else:
        if sortby == 1:
            #distance
            ind = 3
        elif sortby == 2:
            #calories 
            ind = 1
            rev = -1
        elif sortby == 3:
            #raitings
            ind = 4
            rev = -1          
        elif sortby == 4:
            #cost
            ind = 1
            
        answ = func(answ, 0, len(answ)-1, ind, rev) 

    
        if len(answ) == 0:
            message = tk.Message(window, text="Sorry there are no matched meals in your given range : (")
            message.place( x= 540, y = 380)
            message.after(3500, message.destroy)
        elif (money_string.get().isnumeric() and mood == 1) or (mood == 2 and calories_string.get().isnumeric()):
            #open new window   
            window2 = tk.Toplevel(window)
            window2.title("Matched Meals")
            window2.geometry("900x500")
            cnt_window2 += 1
            
            scrollbar = tk.Scrollbar(window2)
            scrollbar.pack( side = 'right', fill = 'both' )
            
            mylist = tk.Listbox(window2, yscrollcommand = scrollbar.set )

            for i in range(len(answ)):
                mylist.insert('end', str(myData[int(answ[i][0])]['restaurant_name']))


            mylist.pack(side = 'left', fill = 'both' )
            scrollbar.config(command = mylist.yview )
            mylist.bind('<<ListboxSelect>>',onselect)
            
            res_name_label = tk.Label(window2) 
            res_name_label.place(x = RES_NAME_LABEL_X, y = RES_NAME_LABEL_Y) 
            
            res_rating_label = tk.Label(window2)
            res_rating_label.place( x = RES_NAME_LABEL_X, y = RES_NAME_LABEL_Y + 30) 
           
            max_calories_label = tk.Label(window2)
            max_calories_label.place(x = RES_NAME_LABEL_X, y = RES_NAME_LABEL_Y + 90) 
            
            ingredients_label = tk.Label(window2, justify = 'left')
            ingredients_label.place(x = RES_NAME_LABEL_X, y = RES_NAME_LABEL_Y + 150)

            distance_label = tk.Label(window2)
            distance_label.place(x = RES_NAME_LABEL_X, y = RES_NAME_LABEL_Y + 60)
            
            items_label = tk.Label(window2)
            items_label.place(x = RES_NAME_LABEL_X, y = RES_NAME_LABEL_Y + 120)
           

          
        else:
                message = tk.Message(window, text="Please enter a valid integer number and choose a mood : )")
                message.place( x= 540, y = 380)
                message.after(3000, message.destroy)

finish_button = tk.Button(window, text = 'Show matched meals', command=new_activity)
finish_button.place(x = 350, y = 400)


calculate_distance()

window.mainloop()
        
  

